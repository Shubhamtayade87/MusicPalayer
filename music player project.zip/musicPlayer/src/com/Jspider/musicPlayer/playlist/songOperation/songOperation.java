package com.Jspider.musicPlayer.playlist.songOperation;
import com.Jspider.musicPlayer.playlist.Songs;

public class songOperation {
	private int id;
	private String name;
	private String album;
	private double length;
	private String singer;
	private String composer;
	private String lyricist;
	
	public songOperation id (int id) {
		this.id = id;
		return this;
	}
	
	public songOperation name (String name) {
		this.name = name;
		return this;
	}
	
	public songOperation album (String album) {
		this.album = album;
		return this;
	}
	
	public songOperation length (double length) {
		this.length = length;
		return this;
	}
	
	public songOperation singer (String singer) {
		this.singer= singer;
		return this;
	}
	public songOperation composer (String composer) {
		this.composer = composer;
		return this;
	}
	public songOperation lyricist (String lyricist) {
		this.lyricist = lyricist;
		return this;
	}

}
