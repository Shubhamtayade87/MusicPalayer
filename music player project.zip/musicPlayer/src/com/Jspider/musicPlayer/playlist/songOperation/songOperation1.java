package com.Jspider.musicPlayer.playlist.songOperation;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.Jspider.musicPlayer.playlist.Songs;

public class songOperation1 {

	static Scanner scanner = new Scanner(System.in);
	static ArrayList arrayList = new ArrayList();
	static Iterator iterator = arrayList.iterator();
	static songOperation1 operation1 = new songOperation1();
	static Songs songs;

	public void addSongs() {
		System.out.println("How many songs to be add");

		int songAdd = scanner.nextInt();
		for (int i = 0; i < songAdd; i++) {
			Songs songs = new Songs();

			System.out.println("Enter Id");
			int id = scanner.nextInt();
			songs.setId(id);
			System.out.println("Enter name");
			String name = scanner.next();
			songs.setName(name);
			System.out.println("Enter the movie/album");
			String album = scanner.next();
			songs.setAlbum(album);

			System.out.println("Enter Length");
			int length = scanner.nextInt();
			songs.setLength(length);

			System.out.println("Enter singer");
			String singer = scanner.next();
			System.out.println("Enter the composer");
			String composer = scanner.next();
			songs.setComposer(composer);

			System.out.println("Enter the lyricist");
			String lyricist = scanner.next();
			songs.setComposer(composer);

			arrayList.add(songs.getId());
			arrayList.add(songs.getName());
			arrayList.add(songs.getAlbum());
			arrayList.add(songs.getLength());
			arrayList.add(songs.getSinger());
			arrayList.add(songs.getComposer());
			arrayList.add(songs.getLyricist());

			System.out.println("Added Successfully");
		}
		operation1.viewPlaylist();

	}

	public void viewPlaylist() {
		if (arrayList == null) {
			System.out.println("No Songs");
			System.out.println("First add song");
			operation1.addSongs();
		} else {
			while (iterator.hasNext()) {
				System.out.println(songs.getName());
			}
		}

	}


}
